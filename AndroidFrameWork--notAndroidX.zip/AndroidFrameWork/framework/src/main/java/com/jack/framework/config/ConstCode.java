package com.jack.framework.config;

/**
 * code常量配置
 *
 * @Author: JACK-GU
 * @Date: 2018/1/17
 * @E-Mail: 528489389@qq.com
 */

public interface ConstCode {
    //权限请求码
    int PERMISSIONS_REQUEST_CODE = 100;
}
