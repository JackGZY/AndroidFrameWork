package com.jack.framework.base;

/**
 * -
 *
 * @Author: JACK-GU
 * @Date: 2018-08-29 10:24
 * @E-Mail: 528489389@qq.com
 */
public interface BaseMvpView {
}
